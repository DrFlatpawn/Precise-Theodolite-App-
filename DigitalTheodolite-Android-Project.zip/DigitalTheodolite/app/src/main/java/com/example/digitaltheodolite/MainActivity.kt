package com.example.digitaltheodolite

import android.Manifest
import android.content.pm.PackageManager
import android.hardware.GeomagneticField
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity(), SensorEventListener {
    private lateinit var sensorManager: SensorManager
    private lateinit var locationManager: LocationManager
    private lateinit var previewView: PreviewView
    private lateinit var azText: TextView
    private lateinit var altText: TextView
    private lateinit var decText: TextView
    private lateinit var statusText: TextView
    private lateinit var locationText: TextView
    private var latestLocation: Location? = null
    private var declinationDeg = 0.0
    private var lastAz = Double.NaN
    private var lastAlt = Double.NaN
    private val history = ArrayDeque<Pair<Double, Double>>()
    private val permissionRequest = 41

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        buildUi()

        val needed = mutableListOf(Manifest.permission.CAMERA)
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (needed.any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }) {
            ActivityCompat.requestPermissions(this, needed.toTypedArray(), permissionRequest)
        } else {
            startCamera()
            startLocation()
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF101820.toInt())
            setPadding(18, 16, 18, 12)
        }
        fun label(text: String, size: Float, color: Int = 0xFFFFFFFF.toInt(), bold: Boolean = false): TextView =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(color)
                gravity = Gravity.CENTER
                if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            }

        root.addView(label("DIGITAL THEODOLITE", 18f, 0xFF75DCC0.toInt(), true))
        root.addView(label("CAMERA SIGHT  •  TRUE-NORTH CORRECTION", 10f, 0xFFB0BEC5.toInt()))
        val cameraFrame = FrameLayout(this)
        previewView = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
        cameraFrame.addView(previewView, FrameLayout.LayoutParams(-1, -1))
        val crosshair = label("＋", 38f, 0xFFE8F4F2.toInt(), true)
        cameraFrame.addView(crosshair, FrameLayout.LayoutParams(-1, -1))
        root.addView(cameraFrame, LinearLayout.LayoutParams(-1, 0, 1.0f).apply {
            topMargin = 12; bottomMargin = 12
        })

        root.addView(label("AZIMUTH  •  TRUE NORTH", 12f, 0xFF8FA8B5.toInt(), true))
        azText = label("—° —′ —.——————″", 25f, 0xFFFFFFFF.toInt(), true)
        root.addView(azText)
        root.addView(label("ALTITUDE", 12f, 0xFF8FA8B5.toInt(), true))
        altText = label("—° —′ —.——————″", 25f, 0xFFFFFFFF.toInt(), true)
        root.addView(altText)
        decText = label("Decimal: waiting for sensor…", 12f, 0xFFB0BEC5.toInt())
        root.addView(decText)
        statusText = label("Waiting for permissions and sensors…", 11f, 0xFFFFD180.toInt())
        root.addView(statusText)
        locationText = label("Declination: unavailable", 11f, 0xFFB0BEC5.toInt())
        root.addView(locationText)
        setContentView(root)
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            try {
                val provider = providerFuture.get()
                val preview = Preview.Builder().build().also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview)
            } catch (e: Exception) {
                statusText.text = "Camera error: ${e.localizedMessage}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun startLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            locationText.text = "Location permission not granted: using magnetic azimuth"
            return
        }
        try {
            val providers = locationManager.getProviders(true)
            val best = providers.firstOrNull { it == LocationManager.GPS_PROVIDER }
                ?: providers.firstOrNull()
            if (best != null) {
                val last = locationManager.getLastKnownLocation(best)
                if (last != null) updateLocation(last)
                locationManager.requestLocationUpdates(best, 5000L, 5f, object : LocationListener {
                    override fun onLocationChanged(location: Location) = updateLocation(location)
                }, Looper.getMainLooper())
            }
        } catch (_: SecurityException) {
            locationText.text = "Location unavailable: magnetic azimuth only"
        }
    }

    private fun updateLocation(location: Location) {
        latestLocation = location
        val altitude = if (location.hasAltitude()) location.altitude.toFloat() else 0f
        val field = GeomagneticField(
            location.latitude.toFloat(), location.longitude.toFloat(),
            altitude, System.currentTimeMillis()
        )
        declinationDeg = field.declination.toDouble()
        locationText.text = String.format(
            Locale.US, "Declination correction: %+.4f°  •  GPS ±%.0fm",
            declinationDeg, if (location.hasAccuracy()) location.accuracy else -1f
        )
    }

    override fun onResume() {
        super.onResume()
        val rotation = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        if (rotation != null) {
            sensorManager.registerListener(this, rotation, SensorManager.SENSOR_DELAY_GAME)
            statusText.text = "Rotation-vector sensor active • hold phone steady"
        } else {
            statusText.text = "No rotation-vector sensor found on this device"
        }
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ROTATION_VECTOR) return
        val matrix = FloatArray(9)
        SensorManager.getRotationMatrixFromVector(matrix, event.values)

        // Android's rotation matrix maps device coordinates into east/north/up.
        // The rear camera optical axis points approximately along device -Z.
        val east = -matrix[2].toDouble()
        val north = -matrix[5].toDouble()
        val up = -matrix[8].toDouble()

        val magneticAz = normalize360(Math.toDegrees(atan2(east, north)))
        val trueAz = normalize360(magneticAz + declinationDeg)
        val altitude = Math.toDegrees(asin(max(-1.0, min(1.0, up))))

        lastAz = trueAz
        lastAlt = altitude
        history.addLast(Pair(trueAz, altitude))
        while (history.size > 12) history.removeFirst()

        azText.text = formatDms(trueAz, true)
        altText.text = formatDms(altitude, false)
        decText.text = String.format(
            Locale.US, "Azimuth: %.10f°     Altitude: %.10f°", trueAz, altitude
        )
        statusText.text = "LIVE • ${history.size}/12 samples • display precision ≠ sensor accuracy"
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        val message = when (accuracy) {
            SensorManager.SENSOR_STATUS_ACCURACY_HIGH -> "sensor accuracy: high"
            SensorManager.SENSOR_STATUS_ACCURACY_MEDIUM -> "sensor accuracy: medium"
            SensorManager.SENSOR_STATUS_ACCURACY_LOW -> "sensor accuracy: low — calibrate"
            else -> "sensor accuracy: unreliable — move away from magnetic interference"
        }
        statusText.text = message
    }

    private fun normalize360(value: Double): Double {
        var result = value % 360.0
        if (result < 0) result += 360.0
        return result
    }

    private fun formatDms(value: Double, wrap: Boolean): String {
        val absValue = kotlin.math.abs(value)
        var degrees = absValue.toInt()
        val minutesFloat = (absValue - degrees) * 60.0
        var minutes = minutesFloat.toInt()
        var seconds = (minutesFloat - minutes) * 60.0
        // Round to six decimal places of an arcsecond and carry overflow.
        seconds = kotlin.math.round(seconds * 1_000_000.0) / 1_000_000.0
        if (seconds >= 60.0) { seconds = 0.0; minutes++ }
        if (minutes >= 60) { minutes = 0; degrees++ }
        val sign = if (value < 0) "−" else ""
        return String.format(Locale.US, "%s%d° %02d′ %09.6f″", sign, degrees, minutes, seconds)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequest) {
            if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                startCamera()
            }
            startLocation()
        }
    }
}
